package bankApplication;

//CustomerAccount should have an  account number and  a  balance,  along  with  a  set  of  AccountTransaction  objects  representing  transactions  on  that account and allowing us to construct a history of the account.
public class CustomerAccount {

	protected String custID;
	protected String accNumber;
	protected double balance;
	AccountTransaction transactions;
	public CustomerAccount() {
		this.custID = "";
		this.accNumber = "";
		this.balance = 0.0;
	
	}

	public CustomerAccount(String id, String accNo, double accBalance) {
		this.custID = id;
		this.accNumber = accNo;
		this.balance = accBalance;
	}

	public void setPPSN(String accNo) {
		this.accNumber = accNo;
	}
	public void setBalance(double accBalance) {
		this.balance = this.balance + accBalance;
	}

	public void setAccNumber(String accNo) {
		this.accNumber = accNo;
	}
	
	public String getAccNumber() {
		return this.accNumber;
	}
	public String getBalance() {
		String b = Double.toString(this.balance);
		return b;
	}
	public String getID() {
		return this.custID;
	}
	
	public String toString() {
		return ("Account Number: " + this.accNumber + "\n Balance: �" + this.balance + "\n ");
	}
	
}
