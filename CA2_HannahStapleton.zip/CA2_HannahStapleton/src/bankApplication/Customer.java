package bankApplication;

//ArrayList object customer, stores PPS  number,  customer surname, customer first name, customer date of birth, as well as an automatically-generated unique customer ID and a seven-character password
public class Customer {

	protected String PPSN;
	protected String surname;
	protected String name;
	protected String dob;
	protected String id;
	protected String password;

	public Customer() {
		this.PPSN = "";
		this.surname = "";
		this.name = "";
		this.dob = "";
		this.id = "";
		this.password = "";
	}

	public Customer(String custName,String custSurname, String custDOB, String custPPSN, String custID,
			String custPassword) {
		this.PPSN = custPPSN;
		this.surname = custSurname;
		this.name = custName;
		this.dob = custDOB;
		this.id = custID;
		this.password = custPassword;
	}

	public void setPPSN(String custPPSN) {
		this.PPSN = custPPSN;
	}

	public void setSurname(String custSurname) {
		this.surname = custSurname;
	}

	public void setName(String custName) {
		this.name = custName;
	}

	public void setDOB(String custDOB) {
		this.dob = custDOB;
	}

	public void setID(String custID) {
		this.id = custID;
	}

	public void setPassword(String custPassword) {
		this.password = custPassword;
	}
	
	public String getPPSN() {
		return this.PPSN;
	}
	public String getSurname() {
		return this.surname;
	}
	public String getName() {
		return this.name;
	}
	public String getDOB() {
		return this.dob;
	}
	public String getID() {
		return this.id;
	}
	public String getPassword() {
		return this.password;
	}
	
	public String toString()
	{
		return ("Name: " + this.name + " " + this.surname + "\n Date of Birth: " + this.dob + "\n PPSN: " + this.PPSN + "\n Customer ID: " + this.id + "\n Password: " + this.password );
	}
	
}
