package bankApplication;

import java.awt.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;
import java.util.*;
import java.security.SecureRandom;

public class Bank implements ActionListener {

	static ArrayList<AccountTransaction> transList;
	static ArrayList<Customer> custList;
	static ArrayList<CustomerAccount> accList;
	Customer cust;
	CustomerAccount acc;
	AccountTransaction transaction;
	static JFrame frame;
	Scanner scan;
	JPanel layout;
	JPanel center;
	JPanel top;
	JPanel left;
	JPanel right;
	protected JMenu custMenu;
	protected JMenu accountMenu;
	protected JMenuItem custAdd;
	protected JMenuItem custModify;
	protected JMenuItem custDelete;
	protected JMenuItem custDisplay;
	protected JMenuItem accountAdd;
	protected JMenuItem accountModify;
	protected JMenuItem accountDelete;
	protected JMenuItem accountTransaction;
	protected JMenuItem accountDisplay;
	protected String adminPassword;
	protected String accountID;
	String modID;
	JTextField transID;
	ButtonGroup transType;
	JRadioButton rb0;
	JRadioButton rb1;
	JLabel lblFirstName;
	JTextField txtFirstName;
	JLabel lblSurname;
	JTextField txtSurname;
	JLabel lblDOB;
	JTextField txtDOB;
	JLabel lblPPSN;
	JTextField txtPPSN;
	JButton bSubmit;
	JButton bSubmitAcc;
	JButton bSubmitMod;
	JButton bSubmitAccMod;
	JLabel lblAccBal;
	JFormattedTextField txtAccBal;
	JButton bClear;
	JLabel lblAcc;
	JTextField txtAcc;
	Container content;
	JTextArea txtC;
	JTextArea txtL;
	JTextArea txtR;

	public Bank() {
		scan = new Scanner(System.in);
		frame = new JFrame("Bank Application");
		adminPassword = "adm1nBA";
		center = new JPanel();
		top = new JPanel();
		left = new JPanel();
		right = new JPanel();
		content = frame.getContentPane();
		layout = new JPanel(new BorderLayout());
		txtC = new JTextArea("");
		txtL = new JTextArea("");
		txtR = new JTextArea("");
		content.add(layout);
		layout.add(top, BorderLayout.NORTH);
		layout.add(left, BorderLayout.WEST);
		layout.add(right, BorderLayout.EAST);
		layout.add(center, BorderLayout.CENTER);
		center.add(txtC);
		left.add(txtL);
		right.add(txtR);
		JMenuBar bank = new JMenuBar();
		bank.add(custMenu = new JMenu("Customer"));
		bank.add(accountMenu = new JMenu("Customer Account"));
		custMenu.add(custAdd = new JMenuItem("Add Customer"));
		custMenu.add(custModify = new JMenuItem("Modify Customer"));
		custMenu.add(custDelete = new JMenuItem("Delete Customer"));
		custMenu.add(custDisplay = new JMenuItem("Display Customers"));
		accountMenu.add(accountAdd = new JMenuItem("Add Account"));
		accountMenu.add(accountModify = new JMenuItem("Modify Account"));
		accountMenu.add(accountDelete = new JMenuItem("Delete Account"));
		accountMenu.add(accountTransaction = new JMenuItem("Manage Transactions"));
		accountMenu.add(accountDisplay = new JMenuItem("Display Accounts"));
		custAdd.addActionListener(this);
		custModify.addActionListener(this);
		custDelete.addActionListener(this);
		custDisplay.addActionListener(this);
		accountAdd.addActionListener(this);
		accountModify.addActionListener(this);
		accountDelete.addActionListener(this);
		accountTransaction.addActionListener(this);
		accountDisplay.addActionListener(this);

		frame.setJMenuBar(bank);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(900, 700);
		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == custAdd) {
			addCustomers();
		}
		if (e.getSource() == custModify) {
			modCustomers();
		}
		if (e.getSource() == custDelete) {
			deleteCustomers();
		}
		if (e.getSource() == custDisplay) {
			displayCustomers();
		}
		if (e.getSource() == accountAdd) {
			addAccount();
		}
		if (e.getSource() == accountModify) {
			modAccount();
		}
		if (e.getSource() == accountDelete) {
			deleteAccount();
		}
		if (e.getSource() == accountTransaction) {
			manageTransactions();
		}
		if (e.getSource() == accountDisplay) {
			displayAccount();
		}
		if ((e.getSource() == bSubmit) && (bSubmit.getText() != null)) {
			String custName;
			String custSurname;
			String custDOB;
			String custPPSN;
			String custID;
			String custPassword;
			custName = txtFirstName.getText();
			custSurname = txtSurname.getText();
			custDOB = txtDOB.getText();
			custPPSN = txtPPSN.getText();
			custID = UUID.randomUUID().toString();

			custPassword = generatePassword();
			// Message + auto-generated id and password.
			txtC.setText("Auto Generated Password: " + custPassword);
			custList = new ArrayList<Customer>();
			cust = new Customer(custName, custSurname, custDOB, custPPSN, custID, custPassword);
			custList.add(cust);
		}
		if ((e.getSource() == bSubmitAcc) && (bSubmitAcc.getText() != null)) {

			String accNumber;
			double balance;
			accNumber = txtAcc.getText();
			balance = Double.parseDouble(txtAccBal.getText());
			accList = new ArrayList<CustomerAccount>();
			acc = new CustomerAccount(accountID, accNumber, balance);
			accList.add(acc);

		}
		if (e.getSource() == bClear) {
			txtFirstName.setText(null);
			txtSurname.setText(null);
			txtDOB.setText(null);
			txtPPSN.setText(null);

		}
		if (e.getSource() == bSubmitMod) {

			for (Customer x : custList) {
				if (modID == x.getID()) {
					x.setName(txtFirstName.getText());
					x.setSurname(txtSurname.getText());
					x.setDOB(txtDOB.getText());
					x.setPPSN(txtPPSN.getText());
				}
			}
			// any new textbox is set in arraylist
		}
		if (e.getSource() == rb0) {
			for (CustomerAccount y : accList) {
				if (transID.getText() == y.getID()) {

					JTextField date = new JTextField();
					JTextField amount = new JTextField();
					;
					String message = "Please enter the Date of transaction and Amount.";
					int result2 = JOptionPane.showOptionDialog(frame, new Object[] { message, date, amount }, "Login",
							JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
					if (result2 == JOptionPane.OK_OPTION) {

						String accNo = y.getID();
						String d = date.getText();
						String type = "lodgement";
						double bal = Double.parseDouble(amount.getText()) - 15;

						transList = new ArrayList<AccountTransaction>();
						AccountTransaction trans = new AccountTransaction(accNo, d, type, bal);
						trans.setTotal(bal);
						transList.add(trans);
						y.setBalance(trans.getTotal());
					}
				}
			}
		}
		if (e.getSource() == rb1) {
			// Withdrawal
			for (CustomerAccount y : accList) {
				if (transID.getText() == y.getID()) {
					JTextField date = new JTextField();
					JTextField amount = new JTextField();
					;
					String message = "Please enter the Date of transaction and Amount.";
					int result2 = JOptionPane.showOptionDialog(frame, new Object[] { message, date, amount }, "Login",
							JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
					if (result2 == JOptionPane.OK_OPTION) {
						if (Double.parseDouble(amount.getText()) > (Double.parseDouble(y.getBalance()))) {
							txtC.append("ERROR: Balance too low. Transaction Cancelled");
						} else {
							String accNo = y.getID();
							String d = date.getText();
							String type = "Withdrawal";
							double remove = 15 + Double.parseDouble(amount.getText());
							double bal = -remove;

							transList = new ArrayList<AccountTransaction>();
							AccountTransaction trans = new AccountTransaction(accNo, d, type, bal);
							trans.setTotal(bal);
							transList.add(trans);
							y.setBalance(trans.getTotal());
						}
					}
				}
			}
		}
		if (e.getSource() == bSubmitAccMod) {
			for (CustomerAccount y : accList) {
				if (accountID == y.getID()) {
					String accNumber;
					double balance;
					accNumber = txtAcc.getText();
					balance = Double.parseDouble(txtAccBal.getText());
					y.setAccNumber(accNumber);
					y.setBalance(balance);

				}
			}
		}
	}

	public void addCustomers() {
		lblFirstName = new JLabel("First Name");
		txtFirstName = new JTextField(" ");
		lblSurname = new JLabel("Surname");
		txtSurname = new JTextField(" ");
		lblDOB = new JLabel("Date of Birth");
		txtDOB = new JTextField(" ");
		lblPPSN = new JLabel("PPSN");
		txtPPSN = new JTextField(" ");
		bSubmit = new JButton("Submit");
		bClear = new JButton("Clear");
		txtFirstName.addActionListener(this);
		txtSurname.addActionListener(this);
		txtDOB.addActionListener(this);
		txtPPSN.addActionListener(this);
		bSubmit.addActionListener(this);
		bClear.addActionListener(this);
		top.add(lblFirstName);
		top.add(txtFirstName);
		top.add(lblSurname);
		top.add(txtSurname);
		top.add(lblDOB);
		top.add(txtDOB);
		top.add(lblPPSN);
		top.add(txtPPSN);
		top.add(bSubmit);
		top.add(bClear);
	}

	public void modCustomers() {
		bSubmitMod = new JButton("Submit");
		// top.removeAll();
		String name = JOptionPane.showInputDialog("Please enter the Name of the Customer you wish to modify.");

		for (Customer x : custList) {
			if (x.getName() == name) {
				lblFirstName = new JLabel("First Name");
				txtFirstName = new JTextField(x.getName());
				lblSurname = new JLabel("Surname");
				txtSurname = new JTextField(x.getSurname());
				lblDOB = new JLabel("Date of Birth");
				txtDOB = new JTextField(x.getDOB());
				lblPPSN = new JLabel("PPSN");
				txtPPSN = new JTextField(x.getPPSN());
				bSubmitMod.addActionListener(this);
				txtFirstName.addActionListener(this);
				txtSurname.addActionListener(this);
				txtDOB.addActionListener(this);
				txtPPSN.addActionListener(this);
				bSubmitMod.addActionListener(this);
				bClear.addActionListener(this);
				left.add(lblFirstName);
				left.add(txtFirstName);
				left.add(lblSurname);
				left.add(txtSurname);
				left.add(lblDOB);
				left.add(txtDOB);
				left.add(lblPPSN);
				left.add(txtPPSN);
				left.add(bSubmitMod);
				modID = x.getID();
			}
		}

	}

	public void deleteCustomers() {

		// only deleted if no customer accounts
		JTextField ID = new JTextField();
		JPasswordField passField = new JPasswordField();
		String message = "Please enter your user customer ID and password.";
		int result1 = JOptionPane.showOptionDialog(frame, new Object[] { message, ID, passField }, "Login",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
		if (result1 == JOptionPane.OK_OPTION) {
			String p = new String(passField.getPassword());
			for (Customer x : custList) {
				if (x.getID() == ID.getText()) {
					if ((x.getPassword() == p) || (adminPassword == p)) {
						custList.remove(x);
					} else {
						txtC.setText(txtC.getText() + "\n ERROR: Incorrect ID/Password. Delete cancelled");
					}
				} else {
					txtC.setText(txtC.getText() + "\n ERROR: Incorrect ID/Password. Delete cancelled");
				}
			}
		}
		if (result1 == JOptionPane.CANCEL_OPTION) {
			txtC.setText(txtC.getText() + "DELETE cancelled");
		}
	}

	public void displayCustomers() {
		// non editable
		for (Customer x : custList) {
			txtR.setText(x.toString());
		}

	}

	public void addAccount() {
		String ID = JOptionPane.showInputDialog("Please enter the ID of the Customer you wish to add an account to.");
		for (Customer x : custList) {
			if (ID == x.getID()) {
				lblAcc = new JLabel("Account Number");
				txtAcc = new JTextField("                   ");
				lblAccBal = new JLabel("Account Balance");
				txtAccBal = new JFormattedTextField(new DecimalFormat("###,###"));
				bSubmitAcc = new JButton("Submit");
				bClear = new JButton("Clear");
				txtAcc.addActionListener(this);
				txtAccBal.addActionListener(this);
				bSubmitAcc.addActionListener(this);
				bClear.addActionListener(this);
				top.add(lblAcc);
				top.add(txtAcc);
				top.add(lblAccBal);
				top.add(txtAccBal);
				top.add(bSubmitAcc);
				top.add(bClear);
				accountID = x.getID();
			} else {
				txtC.append("\n ERROR: No Customer Matching that ID");
			}
		}

	}

	public void modAccount() {
		String num = JOptionPane.showInputDialog("Please enter the Account Number of the account you wish to modify.");
		for (CustomerAccount y : accList) {
			if (y.getAccNumber() == num) {
				for (Customer x : custList) {
					if (y.getID() == x.getID()) {
						lblAcc = new JLabel("Account Number");
						txtAcc = new JTextField(y.getAccNumber());
						lblAccBal = new JLabel("Account Balance");
						txtAccBal = new JFormattedTextField(new DecimalFormat("###,###"));
						txtAccBal.setText(new String(y.getBalance()));
						bSubmitAccMod = new JButton("Submit");
						bClear = new JButton("Clear");
						txtAcc.addActionListener(this);
						txtAccBal.addActionListener(this);
						bSubmitAccMod.addActionListener(this);
						bClear.addActionListener(this);
						left.add(lblAcc);
						left.add(txtAcc);
						left.add(lblAccBal);
						left.add(txtAccBal);
						left.add(bSubmitAccMod);
						left.add(bClear);
						accountID = y.getID();
					}
				}
			}
		}
		// find account
		// display details in textfields, submit button. deletes original and reenters
		// new one to list

	}

	public void deleteAccount() {
		// only deleted if balance = 0
		JTextField ID = new JTextField();
		JPasswordField passField = new JPasswordField();
		String message = "Please enter your user account number and password.";
		int result1 = JOptionPane.showOptionDialog(frame, new Object[] { message, ID, passField }, "Login",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
		if (result1 == JOptionPane.OK_OPTION) {
			String p = new String(passField.getPassword());
			for (CustomerAccount y : accList) {
				if (y.getAccNumber() == ID.getText()) {
					for (Customer x : custList) {
						if ((x.getID() == y.getID()) && (Double.parseDouble(y.getBalance())==0)){
							if ((x.getPassword() == p) || (adminPassword == p)) {
								accList.remove(y);
								txtC.append("\n Account Removed.");
							} else {
								txtC.append("\n ERROR: Incorrect ID/Password. Delete cancelled");
							}
						} else {
							txtC.append("\n ERROR: Balance is not �0 . Delete cancelled");
						}
					}

				} else {
					txtC.append("\n ERROR: Incorrect ID/Password. Delete cancelled");
				}
			}
		}
		if (result1 == JOptionPane.CANCEL_OPTION) {
			txtC.append("DELETE cancelled");
		}
	}

	public void manageTransactions() {
		transList = new ArrayList<AccountTransaction>();
		transID = new JTextField();
		JPasswordField passField = new JPasswordField();
		String message = "Please enter your Customer account number and password.";
		int result = JOptionPane.showOptionDialog(frame, new Object[] { message, transID, passField }, "Login",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
		if (result == JOptionPane.OK_OPTION) {
			String p = new String(passField.getPassword());
			for (CustomerAccount y : accList) {
				if (y.getAccNumber() == transID.getText()) {
					for (Customer x : custList) {
						if (x.getID() == y.getID()) {
							if ((x.getPassword() == p) || (adminPassword == p)) {
								transType = new ButtonGroup();
								rb0 = new JRadioButton("Lodgement", true);
								transType.add(rb0);
								rb0.addActionListener(this);
								rb1 = new JRadioButton("Withdrawal");
								transType.add(rb1);
								rb1.addActionListener(this);
								center.add(rb0, rb1);
							}
						}
					}
				}
			}
		}
		// balance at beginning, & date, type + amount of each transaction, & cumulative
		// balance

	}

	public void displayAccount() {

		JTextField ID = new JTextField();
		JPasswordField passField = new JPasswordField();
		String message = "Please enter your user account number and password.";
		int result = JOptionPane.showOptionDialog(frame, new Object[] { message, ID, passField }, "Login",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
		if (result == JOptionPane.OK_OPTION) {
			String p = new String(passField.getPassword());
			for (CustomerAccount y : accList) {
				if (y.getAccNumber() == ID.getText()) {
					for (Customer x : custList) {
						if (x.getID() == y.getID()) {
							if ((x.getPassword() == p) || (adminPassword == p)) {
								txtR.setText(y.toString());
								for (AccountTransaction z : transList) {
									if (y.getAccNumber() == z.getAccNumber()) {
										txtR.append(z.toString());
										// balance at beginning, & date, type + amount of each transaction, & cumulative
										// balance
									}
								}
							} else {
								txtR.append("\n ERROR: Incorrect ID/Password. DISPLAY cancelled");
							}
						}
					}

				} else {
					txtR.append("\n ERROR: Incorrect ID/Password. DISPLAY cancelled");
				}
			}
		}
		if (result == JOptionPane.CANCEL_OPTION) {
			txtR.append("DISPLAY cancelled");
		}

	}

	public static String generatePassword() {
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		SecureRandom random = new SecureRandom();
		StringBuilder stringBuild = new StringBuilder();
		for (int i = 0; i < 7; i++) {
			int randomIndex = random.nextInt(chars.length());
			stringBuild.append(chars.charAt(randomIndex));
		}

		return stringBuild.toString();
	}

	public static void main(String[] args) {
		new Bank();
	}

}
