package bankApplication;

public class AccountTransaction {
	
    protected String accNo;
	protected String date;
	protected String type;
	protected double amount;
	protected double total;
	
	public AccountTransaction() {
		this.accNo = "";
		this.date = "";
		this.type = "";
		this.amount = 0.0;
		this.total = 0.0;
	}
	public AccountTransaction(String accNum, String transDate, String transType, double transAmount) {
		this.accNo = accNum;
		this.date = transDate;
		this.type = transType;
		this.amount = transAmount;
	}
	
	public void setDate(String d) {
		this.date = d;
	}
	public void setAmount(double bal) {
		this.amount = bal;
	}
	public void setTotal(double bal) {
		this.total = total + bal;
	}
	
	public String getAccNumber() {
		return this.accNo;
	}
	public double getAmount() {
		return this.amount;
	}
	public double getTotal() {
		return this.total;
	}
	
	public String toString() {
		return ("Date: " + this.date + "\n " + this.type + " of �" + this.amount + "\n            Total Transaction Balance: �" + this.total);
	}
}
