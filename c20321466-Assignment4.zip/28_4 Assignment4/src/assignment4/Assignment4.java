package assignment4;

import java.io.*;
import java.util.concurrent.*;

public class Assignment4 extends Thread {
	static Writer writer;
	static BufferedWriter bWriter;
	static Reader reader;
	static BufferedReader bReader;
	static String data;

	public static void main(String[] args) {
		try {
			writer = new FileWriter("memory.txt"); //create file memory
			bWriter = new BufferedWriter(writer);
			reader = new FileReader("words.txt"); //reading from words text file
			bReader = new BufferedReader(reader);

		} catch (IOException e) {
			e.printStackTrace();
		}
		ExecutorService exService = Executors.newFixedThreadPool(3);
		exService.execute(new Runnable() {
			public void run() {
				synchronized (this) {
					try {
						System.out.println("beginning file transfer...");
						while ((data = bReader.readLine()) != null) { //while there are words to read in file,
							sleep(100); // wait 
							bWriter.write(data); // then write word to memory.txt
							bWriter.newLine();
							bWriter.flush(); // add to file
						}

						if (data == null) { //once all words are read,
							bWriter.close(); // close reader and writer
							bReader.close();
							reader.close();
						}
					} catch (IOException | InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("file transfer complete");
			}
		});

		exService.shutdown();

	}
}
